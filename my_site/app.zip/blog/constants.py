# URL Names
STARTING_PAGE = "starting-page"
POSTS_PAGE = "posts-page"
POSTS_DETAILS_PAGE = "post-detail-page"